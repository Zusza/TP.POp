using System;
using System.Security.Cryptography.X509Certificates;

namespace _28._05._25r
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Time;
            dateTimePicker1.ShowUpDown = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string opis = textBox1.Text;
            TimeSpan czas = dateTimePicker1.Value.TimeOfDay;

            if (zad.ContainsKey(czas))
            {
                label1.Text = "Godzina jest zaj�ta";
                return;
            }
            zad[czas] = opis;
            string poczas = $"{czas:hh\\:mm\\:ss}";
            if (string.IsNullOrEmpty(opis))
            {
                Zadania.Items.Add(poczas);
            }
            else
            {
                Zadania.Items.Add($"{poczas} - {opis}");
            }
            textBox1.Clear();
        }
        public Dictionary<TimeSpan, string> zad = new Dictionary<TimeSpan, string>();
    }
}
